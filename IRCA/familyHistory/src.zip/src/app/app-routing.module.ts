import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrintComponent } from './print/print.component'; 
import { FamilyComponent } from './family/family.component';
import { LoginComponent } from './login/login.component';
import { InfoComponent } from './info/info.component';
import { MedicalHistoryComponent } from './medical-history/medical-history.component';
import { TreatmentComponent } from './treatment/treatment.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'print', component: PrintComponent},
  {path:'family',component:FamilyComponent},
  {path: 'info', component: InfoComponent},
  {path: 'medicals', component: MedicalHistoryComponent},
  {path: 'treatment', component: TreatmentComponent},
  {path:'medical-history',component:MedicalHistoryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

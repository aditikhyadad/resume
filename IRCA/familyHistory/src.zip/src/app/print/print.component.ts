import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

import { SiblingService } from '../shared/sibling.service';
import { SiblingComponent } from '../sibling/sibling.component';
import { Sibling } from '../shared/sibling.model';
import { DetailsService } from '../shared/details.service';
import { DetailsComponent } from '../details/details.component';
import { Details } from '../shared/details.model';
import { Treatment } from '../shared/treatment.model';
import { TreatmentService } from '../shared/treatment.service';
import { TreatmentComponent } from '../treatment/treatment.component';
import { Experience } from '../shared/experience.model';
import { ExperienceService } from '../shared/experience.service';
import { ExperienceComponent } from '../experience/experience.component';
import { AdolescenceService } from '../shared/adolescence.service';
import { Adolescence } from '../shared/adolescence.model';
import { Problems } from '../shared/problems.model';
import { ProblemsService } from '../shared/problems.service';
import { Pattern } from '../shared/pattern.model';
import { PatternService } from '../shared/pattern.service';
import { PatientService } from '../shared/patient.service';
import { Patient } from '../shared/patient.model';

@Component({
  selector: 'app-print',
  templateUrl: './print.component.html',
  styleUrl: './print.component.css',
  providers: [SiblingService],
})
export class PrintComponent {
  sib:Sibling[] = [];
  adolss!: Adolescence;
  adolservice: any;
  expservice:any;
  exp!:Experience;

  constructor(public siblingService: SiblingService, public detailsService: DetailsService ,public treatmentService:TreatmentService, public expp:ExperienceService,public adols:AdolescenceService, public problemsService: ProblemsService, public patternService: PatternService,public patientService:PatientService) { 
    this.adolservice=adols;
    this.expservice=expp;
  }

  // In your component
ngOnInit() {
  this.getAdolData();
  this.getexpData();
  this.siblingService.getSiblingList().subscribe((res) => {
    this.siblingService.sibling = res as Sibling[];
  });

  this.detailsService.getDetailsList().subscribe((res) => {
    this.detailsService.details = res as Details[];
  });

  this.treatmentService.getTreatmentList().subscribe((res)=>{
    this.treatmentService.Treatment = res as Treatment[];
  });
  this.problemsService.getProblemsList().subscribe((res) => {
    this.problemsService.problems = res as Problems[];
  });
  this.patternService.getPatternList().subscribe((res) => {
    console.log(this.patternService.pattern)
    this.patternService.pattern = res as Pattern[];
  });
  this.patientService.getPatientList().subscribe((res) => {
    console.log(this.patientService.Patient)
    this.patientService.Patient = res as Patient[];
  });
  
  //console.log('Sibling Data in ngOnInit:', this.siblingService.sibling);
}

getAdolData() {
  this.adolservice.getAdol().subscribe(
    (data: Adolescence) => {
      this.adolss = data;
      console.log(this.adolss);
    },
    (error: any) => {
      console.error('Error in getAdolData:', error);
    });



}
getexpData() {
  this.expservice.getexp().subscribe(
    (data: Experience) => {
      this.exp = data;
      console.log(this.exp)
    },
    (error:any) => {
      console.error('Error in getAdolData:', error);
    }
  );
}

onSubmit(form: NgForm) {
  window.print();
}
}

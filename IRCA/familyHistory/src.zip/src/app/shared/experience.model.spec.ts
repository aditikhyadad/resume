import { Experience } from './experience.model';

describe('Experience', () => {
  it('should create an instance', () => {
    expect(new Experience()).toBeTruthy();
  });
});

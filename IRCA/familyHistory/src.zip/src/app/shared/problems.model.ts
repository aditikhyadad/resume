export class Problems {
    _id : string;
    depression :  String;
    suicide :  String;
    psychiatric : String;
    alcohol : String;
    drug : String;


    constructor()
    {
        this._id = "";
        this.depression  = "";
        this.suicide  = "";
        this.psychiatric = "";
        this.alcohol = "";
        this.drug = "";
    }
}

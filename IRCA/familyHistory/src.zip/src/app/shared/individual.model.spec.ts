import { Individual } from './individual.model';

describe('Individual', () => {
  it('should create an instance', () => {
    expect(new Individual()).toBeTruthy();
  });
});

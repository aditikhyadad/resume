import { Occupation } from './occupation.model';

describe('Occupation', () => {
  it('should create an instance', () => {
    expect(new Occupation()).toBeTruthy();
  });
});

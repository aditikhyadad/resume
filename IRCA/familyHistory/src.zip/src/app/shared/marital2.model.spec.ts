import { Marital2 } from './marital2.model';

describe('Marital2', () => {
  it('should create an instance', () => {
    expect(new Marital2()).toBeTruthy();
  });
});

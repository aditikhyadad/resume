import { Adolescence } from './adolescence.model';

describe('Adolescence', () => {
  it('should create an instance', () => {
    expect(new Adolescence()).toBeTruthy();
  });
});

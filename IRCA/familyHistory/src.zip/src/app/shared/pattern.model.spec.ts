import { Pattern } from './pattern.model';

describe('Pattern', () => {
  it('should create an instance', () => {
    expect(new Pattern()).toBeTruthy();
  });
});

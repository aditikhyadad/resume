import { FinHistory } from './fin-history.model';

describe('FinHistory', () => {
  it('should create an instance', () => {
    expect(new FinHistory()).toBeTruthy();
  });
});

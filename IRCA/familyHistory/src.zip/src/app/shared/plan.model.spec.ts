import { Plan } from './plan.model';

describe('Plan', () => {
  it('should create an instance', () => {
    expect(new Plan()).toBeTruthy();
  });
});

import { Counsellor } from './counsellor.model';

describe('Counsellor', () => {
  it('should create an instance', () => {
    expect(new Counsellor()).toBeTruthy();
  });
});

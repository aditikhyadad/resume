import { Sibling } from './sibling.model';

describe('Sibling', () => {
  it('should create an instance', () => {
    expect(new Sibling()).toBeTruthy();
  });
});

export class Individual {
    _id: string;
    date:string;
    issues:string;
    date1:string;
    issues1:string;
    date2:string;
    issues2:string;
    date3:string;
    issues3:string;
    date4:string;
    issues4:string;
    date5:string;
    issues5:string;
    date6:string;
    issues6:string;
    date7:string;
    issues7:string;
    date8:string;
    issues8:string;
    date9:string;
    issues9:string;
    date10:string;
    issues10:string;
    date11:string;
    issues11:string;
    constructor() {
     this._id = '';
     this.date= '';
     this.issues='';
     this.date1= '';
     this.issues1='';
     this.date2= '';
     this.issues2='';
     this.date3= '';
     this.issues3='';
     this.date4= '';
     this.issues4='';
     this.date5= '';
     this.issues5='';
     this.date6= '';
     this.issues6='';
     this.date7= '';
     this.issues7='';
     this.date8= '';
     this.issues8='';
     this.date9= '';
     this.issues9='';
     this.date10= '';
     this.issues10='';
     this.date11= '';
     this.issues11='';
     
 }

}

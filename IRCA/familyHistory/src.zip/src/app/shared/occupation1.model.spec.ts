import { Occupation1 } from './occupation1.model';

describe('Occupation1', () => {
  it('should create an instance', () => {
    expect(new Occupation1()).toBeTruthy();
  });
});
